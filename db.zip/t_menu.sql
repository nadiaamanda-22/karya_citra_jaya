-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 07, 2025 at 04:13 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_fix_karya_citra`
--

-- --------------------------------------------------------

--
-- Table structure for table `t_menu`
--

CREATE TABLE `t_menu` (
  `id_menu` int(11) NOT NULL,
  `menu` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `t_menu`
--

INSERT INTO `t_menu` (`id_menu`, `menu`, `created_at`, `updated_at`) VALUES
(1, 'dashboard', '2025-03-05 23:26:16', '2025-03-05 23:26:16'),
(2, 'invoice', '2025-03-05 23:26:16', '2025-03-05 23:26:16'),
(3, 'stok barang', '2025-03-05 23:26:16', '2025-03-05 23:26:16'),
(4, 'kelompok barang', '2025-03-05 23:26:16', '2025-03-05 23:26:16'),
(5, 'pembelian barang', '2025-03-05 23:26:16', '2025-03-05 23:26:16'),
(6, 'customer', '2025-03-05 23:26:16', '2025-03-05 23:26:16'),
(7, 'supplier', '2025-03-05 23:26:16', '2025-03-05 23:26:16'),
(8, 'rekening', '2025-03-05 23:26:16', '2025-03-05 23:26:16'),
(9, 'laporan penjualan', '2025-03-05 23:26:16', '2025-03-05 23:26:16'),
(10, 'laporan pembelian', '2025-03-05 23:26:16', '2025-03-05 23:26:16'),
(11, 'laporan stok', '2025-03-05 23:26:16', '2025-03-05 23:26:16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `t_menu`
--
ALTER TABLE `t_menu`
  ADD PRIMARY KEY (`id_menu`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `t_menu`
--
ALTER TABLE `t_menu`
  MODIFY `id_menu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
